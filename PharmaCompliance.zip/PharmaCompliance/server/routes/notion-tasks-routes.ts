import { Router, Request, Response } from "express";
import { 
  notion,
  findDatabaseByTitle,
  getTasks,
} from "../notion";
import { z } from "zod";
import { fromZodError } from "zod-validation-error";

const router = Router();

// Schema for task creation/update
const taskSchema = z.object({
  title: z.string().min(1, "Title is required"),
  description: z.string().optional(),
  section: z.enum(["USP 795", "USP 797", "USP 800", "USP 825", "General"]),
  priority: z.enum(["High", "Medium", "Low"]),
  dueDate: z.string().optional(),
  pharmacy: z.string().default("Central Pharmacy"),
});

// Get all tasks from Notion
router.get("/notion/tasks", async (req: Request, res: Response) => {
  try {
    // Use the specific Tasks database ID we found
    const tasksDatabaseId = "1fe8b086-9f9e-81cf-ae1a-ec6a8b83091c";
    
    // Get tasks from the database
    const tasks = await getTasks(tasksDatabaseId);
    
    // Filter by pharmacy if specified
    let filteredTasks = tasks;
    if (req.query.pharmacy) {
      const pharmacyFilter = Array.isArray(req.query.pharmacy) 
        ? req.query.pharmacy[0] 
        : req.query.pharmacy;
        
      if (typeof pharmacyFilter === 'string') {
        filteredTasks = filteredTasks.filter(task => {
          if (task.pharmacy && typeof task.pharmacy === 'string') {
            return task.pharmacy.toLowerCase() === pharmacyFilter.toLowerCase();
          }
          return false;
        });
      }
    }
    
    res.json(filteredTasks);
  } catch (error) {
    console.error("Error getting tasks from Notion:", error);
    res.status(500).json({ message: "Failed to get tasks from Notion" });
  }
});

// Create a new task in Notion
router.post("/notion/tasks", async (req: Request, res: Response) => {
  try {
    // Validate request body
    const validatedData = taskSchema.parse(req.body);
    
    // Use the specific Tasks database ID we found
    const tasksDatabaseId = "1fe8b086-9f9e-81cf-ae1a-ec6a8b83091c";
    
    // Create task in Notion
    const response = await notion.pages.create({
      parent: {
        database_id: tasksDatabaseId
      },
      properties: {
        Title: {
          title: [
            {
              text: {
                content: validatedData.title
              }
            }
          ]
        },
        Description: {
          rich_text: [
            {
              text: {
                content: validatedData.description || ""
              }
            }
          ]
        },
        Section: {
          select: {
            name: validatedData.section
          }
        },
        Completed: {
          checkbox: false
        },
        Priority: {
          select: {
            name: validatedData.priority
          }
        },
        Status: {
          select: {
            name: "To Do"
          }
        },
        Pharmacy: {
          select: {
            name: validatedData.pharmacy
          }
        },
        ...(validatedData.dueDate ? {
          DueDate: {
            date: {
              start: validatedData.dueDate
            }
          }
        } : {})
      }
    } as any);
    
    res.status(201).json({
      notionId: response.id,
      title: validatedData.title,
      description: validatedData.description || "",
      section: validatedData.section,
      isCompleted: false,
      status: "To Do",
      priority: validatedData.priority,
      dueDate: validatedData.dueDate,
      completedAt: null,
      pharmacy: validatedData.pharmacy
    });
  } catch (error) {
    if (error instanceof z.ZodError) {
      const validationError = fromZodError(error);
      return res.status(400).json({ message: validationError.message });
    }
    
    console.error("Error creating task in Notion:", error);
    res.status(500).json({ message: "Failed to create task in Notion" });
  }
});

// Update a task in Notion
router.patch("/notion/tasks/:id", async (req: Request, res: Response) => {
  try {
    const { id } = req.params;
    
    // Find the task by ID
    try {
      // Check if the page exists and get its current properties
      await notion.pages.retrieve({ page_id: id });
    } catch (error) {
      return res.status(404).json({ message: "Task not found in Notion" });
    }
    
    // Prepare the update payload
    const updateData: any = {
      properties: {}
    };
    
    // Add fields that are being updated
    if (req.body.title !== undefined) {
      updateData.properties.Title = {
        title: [
          {
            text: {
              content: req.body.title
            }
          }
        ]
      };
    }
    
    if (req.body.description !== undefined) {
      updateData.properties.Description = {
        rich_text: [
          {
            text: {
              content: req.body.description
            }
          }
        ]
      };
    }
    
    if (req.body.section !== undefined) {
      updateData.properties.Section = {
        select: {
          name: req.body.section
        }
      };
    }
    
    if (req.body.isCompleted !== undefined) {
      updateData.properties.Completed = {
        checkbox: req.body.isCompleted
      };
    }
    
    if (req.body.priority !== undefined) {
      updateData.properties.Priority = {
        select: {
          name: req.body.priority
        }
      };
    }
    
    if (req.body.status !== undefined) {
      updateData.properties.Status = {
        select: {
          name: req.body.status
        }
      };
    }
    
    if (req.body.dueDate !== undefined) {
      updateData.properties.DueDate = {
        date: req.body.dueDate ? {
          start: req.body.dueDate
        } : null
      };
    }
    
    if (req.body.completedAt !== undefined) {
      updateData.properties.CompletedAt = {
        date: req.body.completedAt ? {
          start: req.body.completedAt
        } : null
      };
    }
    
    if (req.body.pharmacy !== undefined) {
      updateData.properties.Pharmacy = {
        select: {
          name: req.body.pharmacy
        }
      };
    }
    
    // Update the task in Notion
    await notion.pages.update({
      page_id: id,
      ...updateData
    });
    
    res.json({ 
      notionId: id,
      ...req.body
    });
  } catch (error) {
    console.error("Error updating task in Notion:", error);
    res.status(500).json({ message: "Failed to update task in Notion" });
  }
});

// Delete a task from Notion
router.delete("/notion/tasks/:id", async (req: Request, res: Response) => {
  try {
    const { id } = req.params;
    
    // In Notion API, deleting a page is archiving it
    await notion.pages.update({
      page_id: id,
      archived: true
    });
    
    res.status(204).send();
  } catch (error) {
    console.error("Error deleting task from Notion:", error);
    res.status(500).json({ message: "Failed to delete task from Notion" });
  }
});

export default router;