import { Router, Request, Response } from "express";
import { notion } from "../notion";

const router = Router();

// Route to list all pages the integration has access to
router.get("/notion/access", async (req: Request, res: Response) => {
  try {
    console.log("Listing all accessible pages for the integration");
    
    // First, get the user info to confirm the integration is working
    const user = await notion.users.me({ });  // Pass empty object to fix TypeScript error
    
    // Get all pages the integration has access to
    const response = await notion.search({
      filter: {
        property: "object",
        value: "page"
      }
    });
    
    // Extract basic info about each page
    const pages = response.results.map((page: any) => ({
      id: page.id,
      title: page.properties?.title?.title?.[0]?.plain_text || 
             page.properties?.Title?.title?.[0]?.plain_text || 
             "Untitled",
      url: page.url,
      created_time: page.created_time
    }));
    
    return res.json({
      integration: user.name,
      accessible_pages: pages,
      page_count: pages.length,
      message: "If no pages are listed, you need to share at least one page with this integration"
    });
  } catch (error: any) {
    console.error("Error listing Notion access:", error);
    return res.status(500).json({ 
      message: "Failed to list Notion access", 
      error: error.message 
    });
  }
});

// Route to list all databases the integration has access to
router.get("/notion/databases", async (req: Request, res: Response) => {
  try {
    console.log("Listing all accessible databases for the integration");
    
    // Search for all databases
    const response = await notion.search({
      query: "",
      filter: {
        property: "object",
        value: "database"
      }
    });
    
    // Extract basic info about each database
    const databases = response.results.map((db: any) => ({
      id: db.id,
      title: db.title?.[0]?.plain_text || "Untitled Database",
      url: db.url,
      created_time: db.created_time,
      properties: Object.keys(db.properties || {})
    }));
    
    return res.json({
      accessible_databases: databases,
      database_count: databases.length,
      message: "If no databases are listed, you need to share at least one database with this integration"
    });
  } catch (error: any) {
    console.error("Error listing Notion databases:", error);
    return res.status(500).json({ 
      message: "Failed to list Notion databases", 
      error: error.message 
    });
  }
});

export default router;