import { Router, Request, Response } from "express";
import { notion, getTasks, createDatabaseIfNotExists, findDatabaseByTitle } from "../notion";
import { fromZodError } from "zod-validation-error";
import { z } from "zod";

const router = Router();

// Schema for validating task creation/update
const TaskSchema = z.object({
  title: z.string().min(1, "Title is required"),
  description: z.string().optional().default(""),
  dueDate: z.string().optional().nullable(),
  section: z.string().optional().default("Uncategorized"),
  priority: z.string().optional().nullable(),
  status: z.string().optional().default("To Do"),
  pharmacy: z.string().optional().default("Central Pharmacy"),
});

// Get all tasks from Notion
router.get("/notion/tasks", async (req: Request, res: Response) => {
  try {
    const pharmacy = req.query.pharmacy ? String(req.query.pharmacy) : "Central Pharmacy";
    
    // Find the Tasks database
    const tasksDb = await findDatabaseByTitle("Tasks");
    
    if (!tasksDb) {
      return res.status(404).json({ error: "Tasks database not found in Notion" });
    }
    
    // Get all tasks from the database
    const tasks = await getTasks(tasksDb.id);
    
    // Filter tasks by pharmacy if specified
    const filteredTasks = tasks.filter(task => 
      !pharmacy || task.pharmacy?.toLowerCase() === pharmacy.toLowerCase()
    );
    
    return res.status(200).json(filteredTasks);
  } catch (error) {
    console.error("Error fetching tasks from Notion:", error);
    return res.status(500).json({ error: "Failed to fetch tasks from Notion" });
  }
});

// Create a new task in Notion
router.post("/notion/tasks", async (req: Request, res: Response) => {
  try {
    // Validate request body
    const validationResult = TaskSchema.safeParse(req.body);
    
    if (!validationResult.success) {
      const errorMessage = fromZodError(validationResult.error).message;
      return res.status(400).json({ error: errorMessage });
    }
    
    const taskData = validationResult.data;
    
    // Find the Tasks database
    const tasksDb = await findDatabaseByTitle("Tasks");
    
    if (!tasksDb) {
      return res.status(404).json({ error: "Tasks database not found in Notion" });
    }
    
    // Create task in Notion
    const response = await notion.pages.create({
      parent: {
        database_id: tasksDb.id,
      },
      properties: {
        Title: {
          title: [
            {
              text: {
                content: taskData.title,
              },
            },
          ],
        },
        Description: {
          rich_text: taskData.description
            ? [
                {
                  text: {
                    content: taskData.description,
                  },
                },
              ]
            : [],
        },
        Section: {
          select: {
            name: taskData.section || "Uncategorized",
          },
        },
        Completed: {
          checkbox: false,
        },
        Status: {
          select: {
            name: taskData.status || "To Do",
          }
        },
        Priority: taskData.priority
          ? {
              select: {
                name: taskData.priority,
              },
            }
          : null,
        DueDate: taskData.dueDate
          ? {
              date: {
                start: taskData.dueDate,
              },
            }
          : null,
        Pharmacy: {
          rich_text: [
            {
              text: {
                content: taskData.pharmacy || "Central Pharmacy",
              },
            },
          ],
        },
      },
    });
    
    // Get the created task (simplified)
    const createdTask = {
      notionId: response.id,
      title: taskData.title,
      description: taskData.description || "",
      section: taskData.section || "Uncategorized",
      isCompleted: false,
      dueDate: taskData.dueDate || null,
      completedAt: null,
      priority: taskData.priority || null,
      status: taskData.status || "To Do",
      pharmacy: taskData.pharmacy || "Central Pharmacy",
    };
    
    return res.status(201).json(createdTask);
  } catch (error) {
    console.error("Error creating task in Notion:", error);
    return res.status(500).json({ error: "Failed to create task in Notion" });
  }
});

// Update a task in Notion
router.patch("/notion/tasks/:id", async (req: Request, res: Response) => {
  try {
    const taskId = req.params.id;
    
    // Partial validation of request body
    const validationResult = TaskSchema.partial().safeParse(req.body);
    
    if (!validationResult.success) {
      const errorMessage = fromZodError(validationResult.error).message;
      return res.status(400).json({ error: errorMessage });
    }
    
    const taskUpdate = validationResult.data;
    
    // Prepare properties to update
    const properties: any = {};
    
    if (taskUpdate.title !== undefined) {
      properties.Title = {
        title: [
          {
            text: {
              content: taskUpdate.title,
            },
          },
        ],
      };
    }
    
    if (taskUpdate.description !== undefined) {
      properties.Description = {
        rich_text: taskUpdate.description
          ? [
              {
                text: {
                  content: taskUpdate.description,
                },
              },
            ]
          : [],
      };
    }
    
    if (taskUpdate.section !== undefined) {
      properties.Section = {
        select: {
          name: taskUpdate.section,
        },
      };
    }
    
    if (taskUpdate.status !== undefined) {
      properties.Status = {
        select: {
          name: taskUpdate.status,
        },
      };
    }
    
    if (taskUpdate.priority !== undefined) {
      properties.Priority = taskUpdate.priority
        ? {
            select: {
              name: taskUpdate.priority,
            },
          }
        : null;
    }
    
    if (taskUpdate.dueDate !== undefined) {
      properties.DueDate = taskUpdate.dueDate
        ? {
            date: {
              start: taskUpdate.dueDate,
            },
          }
        : null;
    }
    
    // Check if we are marking as completed
    const isCompleted = req.body.isCompleted !== undefined ? req.body.isCompleted : undefined;
    
    if (isCompleted !== undefined) {
      properties.Completed = {
        checkbox: isCompleted,
      };
      
      // If it's completed, add completed date
      if (isCompleted) {
        properties.CompletedAt = {
          date: {
            start: new Date().toISOString().split('T')[0],
          },
        };
        
        // Also update the status to "Done" if it's completed
        properties.Status = {
          select: {
            name: "Done",
          },
        };
      } else {
        // If uncompleting, clear the completed date
        properties.CompletedAt = null;
      }
    }
    
    // Update task in Notion
    await notion.pages.update({
      page_id: taskId,
      properties,
    });
    
    // Return success
    return res.status(200).json({ success: true, message: "Task updated successfully" });
  } catch (error) {
    console.error("Error updating task in Notion:", error);
    return res.status(500).json({ error: "Failed to update task in Notion" });
  }
});

// Delete a task in Notion (archive it)
router.delete("/notion/tasks/:id", async (req: Request, res: Response) => {
  try {
    const taskId = req.params.id;
    
    // Archive the page in Notion (Notion doesn't actually delete pages, just archives them)
    await notion.pages.update({
      page_id: taskId,
      archived: true,
    });
    
    return res.status(200).json({ success: true, message: "Task deleted successfully" });
  } catch (error) {
    console.error("Error deleting task in Notion:", error);
    return res.status(500).json({ error: "Failed to delete task in Notion" });
  }
});

export default router;