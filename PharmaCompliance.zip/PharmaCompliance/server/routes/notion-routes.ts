import { Router, Request, Response } from "express";
import { 
    findDatabaseByTitle, 
    getRiskAssessments, 
    createRiskAssessment,
    updateRiskAssessment
} from "../notion";
import { z } from "zod";

const router = Router();

// Schema for validating risk assessment data from frontend
const riskAssessmentSchema = z.object({
    title: z.string(),
    description: z.string().optional(),
    usp_chapter: z.string(),
    likelihood: z.number(),
    impact: z.number(),
    detection_difficulty: z.number(),
    risk_level: z.number().optional(),
    current_controls: z.string().optional(),
    mitigation_plan: z.string().optional(),
    mitigation_status: z.string(),
    owner: z.string().optional(),
    due_date: z.string().optional(),
    pharmacyId: z.string().optional()
});

// Get all risk assessments from Notion
router.get("/notion/risk-assessments", async (req: Request, res: Response) => {
    try {
        // Find the Risk Assessments database
        const riskAssessmentsDb = await findDatabaseByTitle("Risk Assessments");
        
        if (!riskAssessmentsDb) {
            return res.status(404).json({ error: "Risk Assessments database not found in Notion" });
        }
        
        // Get risk assessments from the database
        const risks = await getRiskAssessments(riskAssessmentsDb.id);
        
        // Filter by chapter if specified
        let filteredRisks = risks;
        if (req.query.chapter && typeof req.query.chapter === 'string') {
            filteredRisks = risks.filter(risk => risk.usp_chapter === req.query.chapter);
        }
        
        // Filter by pharmacy if specified
        if (req.query.pharmacy && typeof req.query.pharmacy === 'string') {
            filteredRisks = filteredRisks.filter(risk => 
                risk.pharmacyId.toLowerCase() === req.query.pharmacy.toLowerCase()
            );
        }
        
        res.json(filteredRisks);
    } catch (error) {
        console.error("Error getting risk assessments from Notion:", error);
        res.status(500).json({ error: "Failed to get risk assessments from Notion" });
    }
});

// Create a new risk assessment in Notion
router.post("/notion/risk-assessments", async (req: Request, res: Response) => {
    try {
        // Validate the request body
        const validationResult = riskAssessmentSchema.safeParse(req.body);
        
        if (!validationResult.success) {
            return res.status(400).json({ 
                error: "Invalid risk assessment data", 
                details: validationResult.error.format() 
            });
        }
        
        // Find the Risk Assessments database
        const riskAssessmentsDb = await findDatabaseByTitle("Risk Assessments");
        
        if (!riskAssessmentsDb) {
            return res.status(404).json({ error: "Risk Assessments database not found in Notion" });
        }
        
        // Calculate risk level if not provided
        const riskData = validationResult.data;
        if (!riskData.risk_level) {
            riskData.risk_level = riskData.likelihood * riskData.impact;
        }
        
        // Create risk assessment in Notion
        const response = await createRiskAssessment(riskAssessmentsDb.id, riskData);
        
        res.status(201).json({
            message: "Risk assessment created successfully",
            riskId: response.id
        });
    } catch (error) {
        console.error("Error creating risk assessment in Notion:", error);
        res.status(500).json({ error: "Failed to create risk assessment in Notion" });
    }
});

// Update an existing risk assessment in Notion
router.patch("/notion/risk-assessments/:id", async (req: Request, res: Response) => {
    try {
        // Validate the request body
        const validationResult = riskAssessmentSchema.partial().safeParse(req.body);
        
        if (!validationResult.success) {
            return res.status(400).json({ 
                error: "Invalid risk assessment data", 
                details: validationResult.error.format() 
            });
        }
        
        const riskData = validationResult.data;
        
        // Update risk level if likelihood or impact are provided but risk_level isn't
        if ((riskData.likelihood || riskData.impact) && !riskData.risk_level) {
            // Get the current values from the database if not provided in the update
            if (!riskData.likelihood || !riskData.impact) {
                // Since we can't easily query a single page with the Notion API,
                // we'll have to use the current values from the request
                const likelihood = riskData.likelihood || req.body.currentLikelihood || 1;
                const impact = riskData.impact || req.body.currentImpact || 1;
                riskData.risk_level = likelihood * impact;
            } else {
                riskData.risk_level = riskData.likelihood * riskData.impact;
            }
        }
        
        // Update risk assessment in Notion
        await updateRiskAssessment(req.params.id, riskData);
        
        res.json({
            message: "Risk assessment updated successfully"
        });
    } catch (error) {
        console.error("Error updating risk assessment in Notion:", error);
        res.status(500).json({ error: "Failed to update risk assessment in Notion" });
    }
});

export default router;