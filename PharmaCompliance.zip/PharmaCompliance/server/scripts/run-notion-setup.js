// Run-script to set up Notion databases
require('dotenv').config(); // Load environment variables
const { exec } = require('child_process');

console.log('Starting Notion database setup...');

// Execute the TypeScript setup file using tsx
exec('npx tsx server/scripts/setup-notion-database.ts', (error, stdout, stderr) => {
  if (error) {
    console.error(`Error executing setup script: ${error.message}`);
    return;
  }
  
  if (stderr) {
    console.error(`Setup script error: ${stderr}`);
  }
  
  console.log(stdout);
  console.log('Notion database setup completed!');
});