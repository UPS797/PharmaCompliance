import { db } from '../db';
import * as schema from '../../shared/schema';
import { sql } from 'drizzle-orm';

async function createTables() {
  try {
    console.log('Creating database tables...');
    
    // Create users table
    await db.execute(sql`
      CREATE TABLE IF NOT EXISTS users (
        id SERIAL PRIMARY KEY,
        username TEXT NOT NULL UNIQUE,
        password TEXT NOT NULL,
        name TEXT NOT NULL,
        role TEXT NOT NULL,
        email TEXT,
        pharmacy TEXT
      )
    `);
    console.log('Users table created.');

    // Create USP chapters table
    await db.execute(sql`
      CREATE TABLE IF NOT EXISTS usp_chapters (
        id SERIAL PRIMARY KEY,
        number TEXT NOT NULL,
        title TEXT NOT NULL,
        description TEXT
      )
    `);
    console.log('USP chapters table created.');

    // Create requirements table
    await db.execute(sql`
      CREATE TABLE IF NOT EXISTS requirements (
        id SERIAL PRIMARY KEY,
        chapter_id INTEGER NOT NULL,
        section TEXT,
        title TEXT NOT NULL,
        description TEXT,
        criticality TEXT NOT NULL
      )
    `);
    console.log('Requirements table created.');

    // Create compliance table
    await db.execute(sql`
      CREATE TABLE IF NOT EXISTS compliance (
        id SERIAL PRIMARY KEY,
        requirement_id INTEGER NOT NULL,
        pharmacy_id TEXT NOT NULL,
        status TEXT NOT NULL,
        evidence TEXT,
        last_updated TIMESTAMP,
        updated_by INTEGER
      )
    `);
    console.log('Compliance table created.');

    // Create tasks table
    await db.execute(sql`
      CREATE TABLE IF NOT EXISTS tasks (
        id SERIAL PRIMARY KEY,
        title TEXT NOT NULL,
        description TEXT,
        due_date TIMESTAMP,
        assigned_to INTEGER,
        status TEXT NOT NULL,
        requirement_id INTEGER,
        pharmacy_id TEXT NOT NULL,
        priority TEXT NOT NULL,
        created_at TIMESTAMP,
        created_by INTEGER
      )
    `);
    console.log('Tasks table created.');

    // Create documents table
    await db.execute(sql`
      CREATE TABLE IF NOT EXISTS documents (
        id SERIAL PRIMARY KEY,
        title TEXT NOT NULL,
        filename TEXT NOT NULL,
        type TEXT NOT NULL,
        version TEXT,
        uploaded_by INTEGER,
        uploaded_at TIMESTAMP,
        pharmacy_id TEXT NOT NULL,
        chapter_id INTEGER,
        content TEXT
      )
    `);
    console.log('Documents table created.');

    // Create training table
    await db.execute(sql`
      CREATE TABLE IF NOT EXISTS training (
        id SERIAL PRIMARY KEY,
        user_id INTEGER NOT NULL,
        title TEXT NOT NULL,
        description TEXT,
        completed_at TIMESTAMP,
        expires_at TIMESTAMP,
        chapter_id INTEGER,
        pharmacy_id TEXT NOT NULL,
        status TEXT NOT NULL,
        verified_by INTEGER
      )
    `);
    console.log('Training table created.');

    // Create audits table
    await db.execute(sql`
      CREATE TABLE IF NOT EXISTS audits (
        id SERIAL PRIMARY KEY,
        user_id INTEGER,
        action TEXT NOT NULL,
        details TEXT,
        timestamp TIMESTAMP NOT NULL,
        pharmacy_id TEXT NOT NULL,
        resource_type TEXT,
        resource_id INTEGER
      )
    `);
    console.log('Audits table created.');

    // Create gap analysis table
    await db.execute(sql`
      CREATE TABLE IF NOT EXISTS gap_analysis (
        id SERIAL PRIMARY KEY,
        title TEXT NOT NULL,
        description TEXT,
        chapter_id INTEGER NOT NULL,
        pharmacy_id TEXT NOT NULL,
        status TEXT NOT NULL,
        findings JSONB,
        created_at TIMESTAMP,
        created_by INTEGER,
        completed_at TIMESTAMP
      )
    `);
    console.log('Gap analysis table created.');

    // Create inspections table
    await db.execute(sql`
      CREATE TABLE IF NOT EXISTS inspections (
        id SERIAL PRIMARY KEY,
        title TEXT NOT NULL,
        description TEXT,
        scheduled_date TIMESTAMP,
        pharmacy_id TEXT NOT NULL,
        status TEXT NOT NULL,
        inspector_name TEXT,
        findings JSONB,
        created_by INTEGER,
        created_at TIMESTAMP
      )
    `);
    console.log('Inspections table created.');

    // Create environmental monitoring table
    await db.execute(sql`
      CREATE TABLE IF NOT EXISTS environmental_monitoring (
        id SERIAL PRIMARY KEY,
        location TEXT NOT NULL,
        record_type TEXT NOT NULL,
        value NUMERIC NOT NULL,
        unit TEXT NOT NULL,
        status TEXT NOT NULL,
        recorded_at TIMESTAMP NOT NULL,
        recorded_by INTEGER,
        pharmacy_id TEXT NOT NULL,
        notes TEXT
      )
    `);
    console.log('Environmental monitoring table created.');

    console.log('All tables created successfully.');
  } catch (error) {
    console.error('Error creating tables:', error);
  } finally {
    process.exit();
  }
}

createTables();