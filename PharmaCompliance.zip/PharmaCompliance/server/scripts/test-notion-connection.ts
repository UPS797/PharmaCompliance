import { Client } from "@notionhq/client";

// Environment variables validation
if (!process.env.NOTION_INTEGRATION_SECRET) {
    throw new Error("NOTION_INTEGRATION_SECRET is not defined. Please add it to your environment variables.");
}

// Initialize Notion client
const notion = new Client({
    auth: process.env.NOTION_INTEGRATION_SECRET!,
});

async function testConnection() {
    try {
        // Try listing users to test connection
        const response = await notion.users.list({});
        console.log("Successfully connected to Notion!");
        console.log(`Bot user ID: ${response.results[0].id}`);
        console.log(`Bot user name: ${response.results[0].name}`);
        
        return true;
    } catch (error) {
        console.error("Error connecting to Notion:", error);
        return false;
    }
}

async function main() {
    console.log("Testing Notion connection...");
    const success = await testConnection();
    
    if (success) {
        console.log("Connection test successful!");
        process.exit(0);
    } else {
        console.error("Connection test failed!");
        process.exit(1);
    }
}

// Run the test
main();