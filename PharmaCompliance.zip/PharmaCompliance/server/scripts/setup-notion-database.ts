import { notion, NOTION_PAGE_ID, createDatabaseIfNotExists, findDatabaseByTitle } from "../notion";

// Environment variables validation
if (!process.env.NOTION_INTEGRATION_SECRET) {
  throw new Error("NOTION_INTEGRATION_SECRET is not defined. Please add it to your environment variables.");
}

if (!NOTION_PAGE_ID) {
  throw new Error("NOTION_PAGE_ID is not defined. Please set NOTION_PAGE_URL environment variable.");
}

async function setupNotionDatabases() {
  console.log("Setting up Notion databases for pharmacy compliance...");
  
  // Create Tasks database with pharmacy compliance fields
  await createDatabaseIfNotExists("Pharmacy Compliance Tasks", {
    // Every database needs a Title property
    Title: {
      title: {}
    },
    Description: {
      rich_text: {}
    },
    // USP Chapter categorization
    USPChapter: {
      select: {
        options: [
          { name: "USP 795", color: "blue" },
          { name: "USP 797", color: "green" },
          { name: "USP 800", color: "orange" },
          { name: "USP 825", color: "purple" },
          { name: "General", color: "gray" }
        ]
      }
    },
    Priority: {
      select: {
        options: [
          { name: "High", color: "red" },
          { name: "Medium", color: "yellow" },
          { name: "Low", color: "green" }
        ]
      }
    },
    Status: {
      select: {
        options: [
          { name: "To Do", color: "gray" },
          { name: "In Progress", color: "blue" },
          { name: "Completed", color: "green" },
          { name: "Blocked", color: "red" }
        ]
      }
    },
    Completed: {
      checkbox: {}
    },
    DueDate: {
      date: {}
    },
    CompletedAt: {
      date: {}
    },
    // Pharmacy location assignment
    Pharmacy: {
      select: {
        options: [
          { name: "Central Pharmacy", color: "blue" },
          { name: "North Campus", color: "green" },
          { name: "South Campus", color: "yellow" },
          { name: "Oncology Center", color: "purple" },
          { name: "Satellite Clinic", color: "orange" }
        ]
      }
    },
    AssignedTo: {
      rich_text: {}
    }
  });

  // Create Risk Assessments database
  await createDatabaseIfNotExists("Risk Assessments", {
    Title: {
      title: {}
    },
    Description: {
      rich_text: {}
    },
    USPChapter: {
      select: {
        options: [
          { name: "USP 795", color: "blue" },
          { name: "USP 797", color: "green" },
          { name: "USP 800", color: "orange" },
          { name: "USP 825", color: "purple" },
          { name: "General", color: "gray" }
        ]
      }
    },
    RiskLevel: {
      select: {
        options: [
          { name: "Critical", color: "red" },
          { name: "High", color: "orange" },
          { name: "Medium", color: "yellow" },
          { name: "Low", color: "green" }
        ]
      }
    },
    Status: {
      select: {
        options: [
          { name: "Identified", color: "gray" },
          { name: "Assessed", color: "yellow" },
          { name: "Mitigated", color: "blue" },
          { name: "Resolved", color: "green" }
        ]
      }
    },
    Findings: {
      rich_text: {}
    },
    MitigationPlan: {
      rich_text: {}
    },
    AssessmentDate: {
      date: {}
    },
    NextReviewDate: {
      date: {}
    },
    Pharmacy: {
      select: {
        options: [
          { name: "Central Pharmacy", color: "blue" },
          { name: "North Campus", color: "green" },
          { name: "South Campus", color: "yellow" },
          { name: "Oncology Center", color: "purple" },
          { name: "Satellite Clinic", color: "orange" }
        ]
      }
    }
  });

  console.log("Notion databases setup complete!");
}

async function createSampleData() {
  try {
    console.log("Adding sample data to Notion databases...");

    // Find the databases
    const tasksDb = await findDatabaseByTitle("Pharmacy Compliance Tasks");
    const riskDb = await findDatabaseByTitle("Risk Assessments");

    if (!tasksDb || !riskDb) {
      throw new Error("Could not find the required databases.");
    }

    // Create sample tasks for different USP chapters
    const tasks = [
      {
        title: "Review non-sterile compounding procedures",
        description: "Conduct a quarterly review of all non-sterile compounding procedures to ensure compliance with USP 795 guidelines.",
        usp_chapter: "USP 795",
        priority: "High",
        pharmacy: "Central Pharmacy"
      },
      {
        title: "Update cleaning logs for clean room",
        description: "Ensure all cleaning logs for the sterile compounding area are up to date according to USP 797 requirements.",
        usp_chapter: "USP 797",
        priority: "Medium",
        pharmacy: "Central Pharmacy"
      },
      {
        title: "Conduct hazardous drug handling training",
        description: "Schedule and complete training sessions for all staff on proper handling of hazardous drugs as required by USP 800.",
        usp_chapter: "USP 800",
        priority: "High",
        pharmacy: "Oncology Center"
      },
      {
        title: "Verify radiopharmaceutical compounding compliance",
        description: "Audit the radiopharmaceutical compounding processes to ensure they meet USP 825 standards.",
        usp_chapter: "USP 825",
        priority: "Medium",
        pharmacy: "North Campus"
      },
      {
        title: "Update environmental monitoring procedures",
        description: "Review and update environmental monitoring procedures for all sterile compounding areas.",
        usp_chapter: "USP 797",
        priority: "Medium",
        pharmacy: "South Campus"
      },
      {
        title: "Conduct staff competency assessments",
        description: "Complete annual competency assessments for all staff involved in compounding activities.",
        usp_chapter: "General",
        priority: "High",
        pharmacy: "Central Pharmacy"
      }
    ];

    // Create sample risk assessments
    const riskAssessments = [
      {
        title: "Hazardous Drug Spill Response",
        description: "Assessment of current hazardous drug spill response protocols and staff preparedness.",
        usp_chapter: "USP 800",
        risk_level: "High",
        findings: "Current spill kits are incomplete and staff demonstrated inconsistent knowledge of spill response procedures.",
        mitigation_plan: "Replace all spill kits and conduct mandatory training sessions on spill response protocols.",
        pharmacy: "Oncology Center"
      },
      {
        title: "Beyond-Use Dating Compliance",
        description: "Evaluation of current beyond-use dating practices for non-sterile compounds.",
        usp_chapter: "USP 795",
        risk_level: "Medium",
        findings: "Some compounds were assigned inappropriate beyond-use dates not supported by stability data.",
        mitigation_plan: "Revise beyond-use dating policies and provide updated reference materials to compounding staff.",
        pharmacy: "Central Pharmacy"
      },
      {
        title: "Clean Room Pressure Differential",
        description: "Assessment of pressure differential monitoring in the sterile compounding areas.",
        usp_chapter: "USP 797",
        risk_level: "Critical",
        findings: "Pressure monitoring system has failed to alert when pressure differentials fall outside acceptable ranges.",
        mitigation_plan: "Replace pressure monitoring system and implement daily manual checks until new system is validated.",
        pharmacy: "North Campus"
      },
      {
        title: "Radiopharmaceutical Shielding Assessment",
        description: "Evaluation of current shielding practices for radiopharmaceutical preparation.",
        usp_chapter: "USP 825",
        risk_level: "High",
        findings: "Current shielding configurations do not provide optimal protection during certain preparation steps.",
        mitigation_plan: "Purchase additional L-block shields and redesign workflow to maximize shielding effectiveness.",
        pharmacy: "North Campus"
      }
    ];

    // Add sample tasks to Notion
    for (const task of tasks) {
      await notion.pages.create({
        parent: {
          database_id: tasksDb.id
        },
        properties: {
          Title: {
            title: [
              {
                text: {
                  content: task.title
                }
              }
            ]
          },
          Description: {
            rich_text: [
              {
                text: {
                  content: task.description
                }
              }
            ]
          },
          USPChapter: {
            select: {
              name: task.usp_chapter
            }
          },
          Priority: {
            select: {
              name: task.priority
            }
          },
          Status: {
            select: {
              name: "To Do"
            }
          },
          Completed: {
            checkbox: false
          },
          DueDate: {
            date: {
              start: new Date(Date.now() + 14 * 24 * 60 * 60 * 1000).toISOString().split('T')[0] // 14 days from now
            }
          },
          Pharmacy: {
            select: {
              name: task.pharmacy
            }
          }
        }
      });
    }

    // Add sample risk assessments to Notion
    for (const risk of riskAssessments) {
      await notion.pages.create({
        parent: {
          database_id: riskDb.id
        },
        properties: {
          Title: {
            title: [
              {
                text: {
                  content: risk.title
                }
              }
            ]
          },
          Description: {
            rich_text: [
              {
                text: {
                  content: risk.description
                }
              }
            ]
          },
          USPChapter: {
            select: {
              name: risk.usp_chapter
            }
          },
          RiskLevel: {
            select: {
              name: risk.risk_level
            }
          },
          Status: {
            select: {
              name: "Identified"
            }
          },
          Findings: {
            rich_text: [
              {
                text: {
                  content: risk.findings
                }
              }
            ]
          },
          MitigationPlan: {
            rich_text: [
              {
                text: {
                  content: risk.mitigation_plan
                }
              }
            ]
          },
          AssessmentDate: {
            date: {
              start: new Date().toISOString().split('T')[0] // Today
            }
          },
          NextReviewDate: {
            date: {
              start: new Date(Date.now() + 90 * 24 * 60 * 60 * 1000).toISOString().split('T')[0] // 90 days from now
            }
          },
          Pharmacy: {
            select: {
              name: risk.pharmacy
            }
          }
        }
      });
    }

    console.log("Sample data created successfully!");
  } catch (error) {
    console.error("Error creating sample data:", error);
  }
}

// Run the setup
setupNotionDatabases()
  .then(() => {
    return createSampleData();
  })
  .then(() => {
    console.log("Notion setup complete! Your pharmacy compliance databases are ready to use.");
    process.exit(0);
  })
  .catch(error => {
    console.error("Setup failed:", error);
    process.exit(1);
  });