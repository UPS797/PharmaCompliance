import { Client } from "@notionhq/client";

// Environment variables validation
if (!process.env.NOTION_INTEGRATION_SECRET) {
    throw new Error("NOTION_INTEGRATION_SECRET is not defined. Please add it to your environment variables.");
}

// Initialize Notion client
const notion = new Client({
    auth: process.env.NOTION_INTEGRATION_SECRET!,
});

// The ID of the page where you want to create the database
// This needs to be a page ID, not a database ID
const DIRECT_PAGE_ID = "1fc8b0869f9e808dbac5c85111ac9633";

async function createTasksDatabase() {
    try {
        console.log("Creating Tasks database in Notion...");
        
        // Create a database
        const response = await notion.databases.create({
            parent: {
                type: "page_id",
                page_id: DIRECT_PAGE_ID
            },
            title: [
                {
                    type: "text",
                    text: {
                        content: "Pharmacy Compliance Tasks"
                    }
                }
            ],
            properties: {
                Title: {
                    title: {}
                },
                Description: {
                    rich_text: {}
                },
                Section: {
                    select: {
                        options: [
                            { name: "USP 795", color: "green" },
                            { name: "USP 797", color: "blue" },
                            { name: "USP 800", color: "red" },
                            { name: "USP 825", color: "purple" },
                            { name: "General", color: "gray" }
                        ]
                    }
                },
                Priority: {
                    select: {
                        options: [
                            { name: "High", color: "red" },
                            { name: "Medium", color: "yellow" },
                            { name: "Low", color: "green" }
                        ]
                    }
                },
                Status: {
                    select: {
                        options: [
                            { name: "To Do", color: "gray" },
                            { name: "In Progress", color: "blue" },
                            { name: "Completed", color: "green" },
                            { name: "Overdue", color: "red" }
                        ]
                    }
                },
                Completed: {
                    checkbox: {}
                },
                DueDate: {
                    date: {}
                },
                CompletedAt: {
                    date: {}
                },
                Pharmacy: {
                    rich_text: {}
                }
            }
        });

        console.log(`Successfully created database with ID: ${response.id}`);
        return response.id;
    } catch (error) {
        console.error("Error creating Tasks database:", error);
        throw error;
    }
}

async function createSampleTasks(databaseId: string) {
    try {
        console.log("Creating sample pharmacy compliance tasks...");

        const tasks = [
            {
                title: "Daily pressure differential check - USP 797",
                description: "Monitor and document pressure differential between clean room and ante-room",
                section: "USP 797",
                priority: "High",
                status: "To Do",
                dueDate: new Date(Date.now() + 3 * 24 * 60 * 60 * 1000), // 3 days from now
                pharmacy: "Central Pharmacy"
            },
            {
                title: "Monthly hood certification - USP 800",
                description: "Perform monthly certification of containment primary engineering control (C-PEC) hoods for handling hazardous drugs",
                section: "USP 800",
                priority: "High",
                status: "To Do",
                dueDate: new Date(Date.now() + 15 * 24 * 60 * 60 * 1000), // 15 days from now
                pharmacy: "Central Pharmacy"
            },
            {
                title: "Temperature monitoring - USP 795",
                description: "Record temperature readings for non-sterile compounding areas",
                section: "USP 795",
                priority: "Medium",
                status: "To Do",
                dueDate: new Date(Date.now() + 1 * 24 * 60 * 60 * 1000), // 1 day from now
                pharmacy: "Central Pharmacy"
            },
            {
                title: "Quarterly staff competency assessment - USP 797",
                description: "Evaluate staff competencies for aseptic technique and cleaning procedures",
                section: "USP 797",
                priority: "Medium",
                status: "To Do",
                dueDate: new Date(Date.now() + 45 * 24 * 60 * 60 * 1000), // 45 days from now
                pharmacy: "Central Pharmacy"
            },
            {
                title: "Annual training review - USP 800",
                description: "Conduct annual review of hazardous drug handling training for all pharmacy personnel",
                section: "USP 800",
                priority: "Medium",
                status: "To Do",
                dueDate: new Date(Date.now() + 60 * 24 * 60 * 60 * 1000), // 60 days from now
                pharmacy: "North Branch"
            },
            {
                title: "Surface sampling for radiopharmaceuticals - USP 825",
                description: "Perform monthly surface sampling for radiopharmaceutical preparation areas",
                section: "USP 825",
                priority: "High",
                status: "To Do",
                dueDate: new Date(Date.now() + 10 * 24 * 60 * 60 * 1000), // 10 days from now
                pharmacy: "South Branch"
            }
        ];

        for (const task of tasks) {
            await notion.pages.create({
                parent: {
                    database_id: databaseId
                },
                properties: {
                    Title: {
                        title: [
                            {
                                text: {
                                    content: task.title
                                }
                            }
                        ]
                    },
                    Description: {
                        rich_text: [
                            {
                                text: {
                                    content: task.description
                                }
                            }
                        ]
                    },
                    Section: {
                        select: {
                            name: task.section
                        }
                    },
                    Priority: {
                        select: {
                            name: task.priority
                        }
                    },
                    Status: {
                        select: {
                            name: task.status
                        }
                    },
                    Completed: {
                        checkbox: false
                    },
                    DueDate: {
                        date: {
                            start: task.dueDate.toISOString().split('T')[0]
                        }
                    },
                    Pharmacy: {
                        rich_text: [
                            {
                                text: {
                                    content: task.pharmacy
                                }
                            }
                        ]
                    }
                }
            });
            console.log(`Created task: ${task.title}`);
        }

        console.log("Sample tasks created successfully!");
    } catch (error) {
        console.error("Error creating sample tasks:", error);
        throw error;
    }
}

async function main() {
    try {
        console.log("Starting Notion database creation for pharmacy compliance tasks...");
        
        // Create the Tasks database
        const databaseId = await createTasksDatabase();
        
        // Create sample tasks
        await createSampleTasks(databaseId);
        
        console.log("Notion integration setup complete!");
        console.log(`Remember to save this database ID for your application: ${databaseId}`);
        
        // Store the database ID in the console output for reference
        console.log("=======================================");
        console.log("NOTION_TASKS_DATABASE_ID=" + databaseId);
        console.log("=======================================");
        
        process.exit(0);
    } catch (error) {
        console.error("Setup failed:", error);
        process.exit(1);
    }
}

// Run the setup
main();