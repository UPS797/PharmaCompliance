import { Client } from "@notionhq/client";
import { notion, NOTION_PAGE_ID, createDatabaseIfNotExists, findDatabaseByTitle } from "../notion";

// Environment variables validation
if (!process.env.NOTION_INTEGRATION_SECRET) {
    throw new Error("NOTION_INTEGRATION_SECRET is not defined. Please add it to your environment variables.");
}

// Setup risk assessment database in Notion
async function setupNotionDatabases() {
    await createDatabaseIfNotExists("Risk Assessments", {
        // Every database needs a Name/Title property
        Title: {
            title: {}
        },
        Description: {
            rich_text: {}
        },
        UspChapter: {
            select: {
                options: [
                    { name: "795", color: "blue" },
                    { name: "797", color: "green" },
                    { name: "800", color: "red" }
                ]
            }
        },
        Likelihood: {
            number: {}
        },
        Impact: {
            number: {}
        },
        DetectionDifficulty: {
            number: {}
        },
        RiskLevel: {
            number: {}
        },
        CurrentControls: {
            rich_text: {}
        },
        MitigationPlan: {
            rich_text: {}
        },
        Status: {
            select: {
                options: [
                    { name: "Not Started", color: "gray" },
                    { name: "In Progress", color: "blue" },
                    { name: "Implemented", color: "green" },
                    { name: "Verified", color: "purple" }
                ]
            }
        },
        Owner: {
            rich_text: {}
        },
        DueDate: {
            date: {}
        },
        Pharmacy: {
            rich_text: {}
        }
    });

    console.log("Risk Assessment database created!");
}

// Create sample risk assessments in Notion
async function createSampleData() {
    try {
        console.log("Adding sample risk assessment data...");

        // Find the Risk Assessments database
        const riskAssessmentsDb = await findDatabaseByTitle("Risk Assessments");

        if (!riskAssessmentsDb) {
            throw new Error("Could not find the Risk Assessments database.");
        }

        const sampleRisks = [
            {
                title: "Cross-contamination in non-sterile compounding",
                description: "Risk of cross-contamination between different compounds in non-sterile preparations",
                usp_chapter: "795",
                likelihood: 4,
                impact: 5,
                detection_difficulty: 3,
                risk_level: 20,
                current_controls: "Separate work areas for different compounds, cleaning between preparations",
                mitigation_plan: "Implement dedicated equipment for high-risk compounds, enhance cleaning protocols",
                mitigation_status: "In Progress",
                owner: "Dr. Maria Chen",
                due_date: new Date(2025, 5, 30).toISOString().split('T')[0],
                pharmacy: "Central Pharmacy"
            },
            {
                title: "Airflow disruption in sterile compounding area",
                description: "Risk of contamination due to inadequate airflow in sterile compounding areas",
                usp_chapter: "797",
                likelihood: 3,
                impact: 5,
                detection_difficulty: 4,
                risk_level: 15,
                current_controls: "Regular airflow testing, HEPA filters",
                mitigation_plan: "Install continuous airflow monitoring system with alerts",
                mitigation_status: "Not Started",
                owner: "Jennifer Wu",
                due_date: new Date(2025, 6, 15).toISOString().split('T')[0],
                pharmacy: "Central Pharmacy"
            },
            {
                title: "Hazardous drug exposure during preparation",
                description: "Staff exposure to hazardous drugs during preparation process",
                usp_chapter: "800",
                likelihood: 3,
                impact: 4,
                detection_difficulty: 3,
                risk_level: 12,
                current_controls: "PPE protocols, containment primary engineering controls",
                mitigation_plan: "Upgrade to closed-system transfer devices, enhanced staff training",
                mitigation_status: "Implemented",
                owner: "Robert Johnson",
                due_date: new Date(2025, 5, 20).toISOString().split('T')[0],
                pharmacy: "Central Pharmacy"
            },
            {
                title: "Temperature excursion in drug storage",
                description: "Risk of temperature excursions affecting drug stability and efficacy",
                usp_chapter: "797",
                likelihood: 2,
                impact: 4,
                detection_difficulty: 2,
                risk_level: 8,
                current_controls: "Manual temperature logs, refrigerator alarms",
                mitigation_plan: "Implement automated temperature monitoring system with remote alerts",
                mitigation_status: "In Progress",
                owner: "Dr. Maria Chen",
                due_date: new Date(2025, 5, 25).toISOString().split('T')[0],
                pharmacy: "Central Pharmacy"
            },
            {
                title: "Incorrect beyond-use date assignment",
                description: "Risk of assigning incorrect beyond-use dates to compounded preparations",
                usp_chapter: "795",
                likelihood: 3,
                impact: 4,
                detection_difficulty: 4,
                risk_level: 12,
                current_controls: "Staff training, BUD calculation worksheets",
                mitigation_plan: "Develop computerized BUD calculator integrated with lab results",
                mitigation_status: "Not Started",
                owner: "Jennifer Wu",
                due_date: new Date(2025, 6, 30).toISOString().split('T')[0],
                pharmacy: "Central Pharmacy"
            }
        ];

        for (const risk of sampleRisks) {
            await notion.pages.create({
                parent: {
                    database_id: riskAssessmentsDb.id
                },
                properties: {
                    Title: {
                        title: [
                            {
                                text: {
                                    content: risk.title
                                }
                            }
                        ]
                    },
                    Description: {
                        rich_text: [
                            {
                                text: {
                                    content: risk.description
                                }
                            }
                        ]
                    },
                    UspChapter: {
                        select: {
                            name: risk.usp_chapter
                        }
                    },
                    Likelihood: {
                        number: risk.likelihood
                    },
                    Impact: {
                        number: risk.impact
                    },
                    DetectionDifficulty: {
                        number: risk.detection_difficulty
                    },
                    RiskLevel: {
                        number: risk.risk_level
                    },
                    CurrentControls: {
                        rich_text: [
                            {
                                text: {
                                    content: risk.current_controls
                                }
                            }
                        ]
                    },
                    MitigationPlan: {
                        rich_text: [
                            {
                                text: {
                                    content: risk.mitigation_plan
                                }
                            }
                        ]
                    },
                    Status: {
                        select: {
                            name: risk.mitigation_status
                        }
                    },
                    Owner: {
                        rich_text: [
                            {
                                text: {
                                    content: risk.owner
                                }
                            }
                        ]
                    },
                    DueDate: {
                        date: {
                            start: risk.due_date
                        }
                    },
                    Pharmacy: {
                        rich_text: [
                            {
                                text: {
                                    content: risk.pharmacy
                                }
                            }
                        ]
                    }
                }
            });
        }

        console.log(`Created sample risk assessments`);
        console.log("Sample data creation complete.");
    } catch (error) {
        console.error("Error creating sample data:", error);
    }
}

// Run the setup
setupNotionDatabases().then(() => {
    return createSampleData();
}).then(() => {
    console.log("Notion setup complete!");
    process.exit(0);
}).catch(error => {
    console.error("Notion setup failed:", error);
    process.exit(1);
});