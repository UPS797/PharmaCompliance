import { db } from '../db';
import * as schema from '../../shared/schema';
import { sql } from 'drizzle-orm';
import { hash } from 'bcrypt';

async function seedDatabase() {
  try {
    console.log('Seeding database with initial data...');
    
    // Seed users
    const hashedPassword = await hash('password123', 10);
    await db.insert(schema.users).values([
      { 
        username: 'admin@pharmacy.com', 
        password: hashedPassword, 
        name: 'Admin User', 
        role: 'admin',
        email: 'admin@pharmacy.com',
        pharmacy: 'Central Pharmacy'
      },
      { 
        username: 'pharmacist@pharmacy.com', 
        password: hashedPassword, 
        name: 'Pharmacist User', 
        role: 'pharmacist',
        email: 'pharmacist@pharmacy.com',
        pharmacy: 'Central Pharmacy'
      },
      { 
        username: 'tech@pharmacy.com', 
        password: hashedPassword, 
        name: 'Pharmacy Tech', 
        role: 'tech',
        email: 'tech@pharmacy.com',
        pharmacy: 'Central Pharmacy'
      }
    ]);
    console.log('Users seeded.');

    // Seed USP chapters
    await db.insert(schema.uspChapters).values([
      { number: '795', title: 'Pharmaceutical Compounding – Nonsterile Preparations', description: 'Standards for nonsterile compounding' },
      { number: '797', title: 'Pharmaceutical Compounding – Sterile Preparations', description: 'Standards for sterile compounding' },
      { number: '800', title: 'Hazardous Drugs – Handling in Healthcare Settings', description: 'Standards for handling hazardous drugs' }
    ]);
    console.log('USP chapters seeded.');

    // Get chapter IDs
    const chapters = await db.select().from(schema.uspChapters);
    const chapter795Id = chapters.find(c => c.number === '795')?.id;
    const chapter797Id = chapters.find(c => c.number === '797')?.id;
    const chapter800Id = chapters.find(c => c.number === '800')?.id;

    // Seed requirements
    if (chapter795Id && chapter797Id && chapter800Id) {
      await db.insert(schema.requirements).values([
        { 
          chapterId: chapter795Id, 
          section: '1.1', 
          title: 'Personnel Qualifications', 
          description: 'All personnel involved in the compounding of nonsterile preparations must be properly trained and qualified.',
          criticality: 'Major'
        },
        { 
          chapterId: chapter795Id, 
          section: '2.3', 
          title: 'Documentation', 
          description: 'Documentation of nonsterile compounding procedures and records must be maintained.',
          criticality: 'Major'
        },
        { 
          chapterId: chapter797Id, 
          section: '1.2', 
          title: 'Facility Design and Environmental Controls', 
          description: 'Proper design and environmental controls for sterile compounding areas.',
          criticality: 'Critical'
        },
        { 
          chapterId: chapter797Id, 
          section: '3.1', 
          title: 'Personnel Training and Evaluation', 
          description: 'All personnel must be properly trained and evaluated in aseptic manipulation skills.',
          criticality: 'Critical'
        },
        { 
          chapterId: chapter800Id, 
          section: '5.1', 
          title: 'Facilities and Engineering Controls', 
          description: 'Proper facilities and engineering controls for handling hazardous drugs.',
          criticality: 'Critical'
        },
        { 
          chapterId: chapter800Id, 
          section: '7.1', 
          title: 'Personal Protective Equipment', 
          description: 'Appropriate PPE must be worn when handling hazardous drugs.',
          criticality: 'Critical'
        }
      ]);
      console.log('Requirements seeded.');

      // Seed compliance records
      const requirements = await db.select().from(schema.requirements);
      for (const req of requirements) {
        await db.insert(schema.compliance).values({
          requirementId: req.id,
          pharmacyId: 'Central Pharmacy',
          status: ['Met', 'Not Met', 'In Progress'][Math.floor(Math.random() * 3)],
          evidence: 'Sample evidence text',
          lastUpdated: new Date(),
          updatedBy: 1
        });
      }
      console.log('Compliance records seeded.');

      // Seed tasks
      await db.insert(schema.tasks).values([
        {
          title: 'Daily temperature monitoring',
          description: 'Check and record temperatures in all compounding areas',
          dueDate: new Date(Date.now() + 86400000), // tomorrow
          assignedTo: 3, // tech
          status: 'Open',
          requirementId: requirements[2].id, // facility design req
          pharmacyId: 'Central Pharmacy',
          priority: 'High',
          createdAt: new Date(),
          createdBy: 1
        },
        {
          title: 'Weekly cleaning verification',
          description: 'Perform and document cleaning of sterile compounding areas',
          dueDate: new Date(Date.now() + 86400000 * 3), // 3 days from now
          assignedTo: 2, // pharmacist
          status: 'Open',
          requirementId: requirements[2].id,
          pharmacyId: 'Central Pharmacy',
          priority: 'Medium',
          createdAt: new Date(),
          createdBy: 1
        },
        {
          title: 'Monthly media fill testing',
          description: 'Conduct media fill tests for all compounding personnel',
          dueDate: new Date(Date.now() + 86400000 * 15), // 15 days from now
          assignedTo: 2,
          status: 'Open',
          requirementId: requirements[3].id,
          pharmacyId: 'Central Pharmacy',
          priority: 'Medium',
          createdAt: new Date(),
          createdBy: 1
        }
      ]);
      console.log('Tasks seeded.');

      // Seed documents
      await db.insert(schema.documents).values([
        {
          title: 'USP 797 Compliance SOP',
          filename: 'usp_797_sop.pdf',
          type: 'SOP',
          version: '1.2',
          uploadedBy: 1,
          uploadedAt: new Date(),
          pharmacyId: 'Central Pharmacy',
          chapterId: chapter797Id,
          content: 'Sample content for USP 797 SOP'
        },
        {
          title: 'Hazardous Drug Handling Policy',
          filename: 'hd_handling_policy.pdf',
          type: 'Policy',
          version: '2.0',
          uploadedBy: 1,
          uploadedAt: new Date(),
          pharmacyId: 'Central Pharmacy',
          chapterId: chapter800Id,
          content: 'Sample content for HD handling policy'
        },
        {
          title: 'Nonsterile Compounding Procedures',
          filename: 'nonsterile_procedures.pdf',
          type: 'Procedure',
          version: '1.1',
          uploadedBy: 1,
          uploadedAt: new Date(),
          pharmacyId: 'Central Pharmacy',
          chapterId: chapter795Id,
          content: 'Sample content for nonsterile compounding procedures'
        }
      ]);
      console.log('Documents seeded.');

      // Seed training records
      await db.insert(schema.training).values([
        {
          userId: 2, // pharmacist
          title: 'USP 797 Initial Training',
          description: 'Comprehensive training on USP 797 standards',
          completedAt: new Date(Date.now() - 86400000 * 180), // 180 days ago
          expiresAt: new Date(Date.now() + 86400000 * 180), // 180 days from now
          chapterId: chapter797Id,
          pharmacyId: 'Central Pharmacy',
          status: 'Completed',
          verifiedBy: 1
        },
        {
          userId: 3, // tech
          title: 'Hazardous Drug Handling',
          description: 'Training on safe handling of hazardous drugs',
          completedAt: new Date(Date.now() - 86400000 * 150), // 150 days ago
          expiresAt: new Date(Date.now() + 86400000 * 210), // 210 days from now
          chapterId: chapter800Id,
          pharmacyId: 'Central Pharmacy',
          status: 'Completed',
          verifiedBy: 1
        },
        {
          userId: 2,
          title: 'Aseptic Technique Assessment',
          description: 'Hands-on evaluation of aseptic technique',
          completedAt: new Date(Date.now() - 86400000 * 120), // 120 days ago
          expiresAt: new Date(Date.now() + 86400000 * 240), // 240 days from now
          chapterId: chapter797Id,
          pharmacyId: 'Central Pharmacy',
          status: 'Completed',
          verifiedBy: 1
        }
      ]);
      console.log('Training records seeded.');

      // Seed audit records
      await db.insert(schema.audits).values([
        {
          userId: 1,
          action: 'Create Document',
          details: 'Created new SOP for sterile compounding',
          timestamp: new Date(Date.now() - 86400000 * 5), // 5 days ago
          pharmacyId: 'Central Pharmacy',
          resourceType: 'Document',
          resourceId: 1
        },
        {
          userId: 2,
          action: 'Update Compliance',
          details: 'Updated compliance status for USP 797 requirement',
          timestamp: new Date(Date.now() - 86400000 * 3), // 3 days ago
          pharmacyId: 'Central Pharmacy',
          resourceType: 'Compliance',
          resourceId: 3
        },
        {
          userId: 1,
          action: 'Complete Training',
          details: 'Verified training completion for pharmacy technician',
          timestamp: new Date(Date.now() - 86400000 * 1), // 1 day ago
          pharmacyId: 'Central Pharmacy',
          resourceType: 'Training',
          resourceId: 2
        }
      ]);
      console.log('Audit records seeded.');

      // Insert environmental monitoring data
      await db.execute(sql`
        INSERT INTO environmental_monitoring (
          location, record_type, value, unit, status, recorded_at, recorded_by, pharmacy_id, notes
        ) VALUES 
        ('Clean Room', 'temperature', 20.5, '°C', 'normal', NOW() - INTERVAL '1 day', 2, 'Central Pharmacy', NULL),
        ('Clean Room', 'pressure', 0.03, 'inWC', 'normal', NOW() - INTERVAL '1 day', 2, 'Central Pharmacy', NULL),
        ('Clean Room', 'humidity', 42, '%RH', 'normal', NOW() - INTERVAL '1 day', 2, 'Central Pharmacy', NULL),
        ('Anteroom', 'temperature', 22.1, '°C', 'normal', NOW() - INTERVAL '1 day', 3, 'Central Pharmacy', NULL),
        ('Anteroom', 'pressure', 0.01, 'inWC', 'warning', NOW() - INTERVAL '1 day', 3, 'Central Pharmacy', 'Pressure below recommended range'),
        ('HD Storage', 'temperature', 18.9, '°C', 'normal', NOW() - INTERVAL '1 day', 2, 'Central Pharmacy', NULL),
        ('Med Refrigerator 1', 'temperature', 4.2, '°C', 'normal', NOW() - INTERVAL '1 day', 3, 'Central Pharmacy', NULL)
      `);
      console.log('Environmental monitoring data seeded.');
    }

    console.log('Database seeding completed successfully.');
  } catch (error) {
    console.error('Error seeding database:', error);
  } finally {
    process.exit();
  }
}

seedDatabase();