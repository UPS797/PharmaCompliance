import { notion, NOTION_PAGE_ID, createDatabaseIfNotExists, findDatabaseByTitle } from "../notion";

// Environment variables validation
if (!process.env.NOTION_INTEGRATION_SECRET) {
    throw new Error("NOTION_INTEGRATION_SECRET is not defined. Please add it to your environment variables.");
}

if (!process.env.NOTION_PAGE_URL) {
    throw new Error("NOTION_PAGE_URL is not defined. Please add it to your environment variables.");
}

// Setup the Tasks database for pharmacy compliance
async function setupTasksDatabase() {
    console.log("Setting up Tasks database in Notion...");
    
    // Create the Tasks database with appropriate schema for pharmacy compliance
    await createDatabaseIfNotExists("Tasks", {
        Title: {
            title: {}
        },
        Description: {
            rich_text: {}
        },
        Section: {
            select: {
                options: [
                    { name: "USP 795 Compliance", color: "green" },
                    { name: "USP 797 Compliance", color: "blue" },
                    { name: "USP 800 Compliance", color: "red" },
                    { name: "USP 825 Compliance", color: "purple" },
                    { name: "Environmental Monitoring", color: "orange" },
                    { name: "Staff Training", color: "pink" },
                    { name: "Documentation", color: "yellow" },
                    { name: "Equipment Maintenance", color: "brown" },
                    { name: "Facility Maintenance", color: "gray" },
                    { name: "Uncategorized", color: "default" }
                ]
            }
        },
        Completed: {
            checkbox: {}
        },
        DueDate: {
            date: {}
        },
        CompletedAt: {
            date: {}
        },
        Priority: {
            select: {
                options: [
                    { name: "High", color: "red" },
                    { name: "Medium", color: "yellow" },
                    { name: "Low", color: "green" }
                ]
            }
        },
        Status: {
            select: {
                options: [
                    { name: "To Do", color: "gray" },
                    { name: "In Progress", color: "blue" },
                    { name: "Done", color: "green" },
                    { name: "Blocked", color: "red" }
                ]
            }
        },
        Pharmacy: {
            rich_text: {}
        }
    });

    console.log("Tasks database setup complete!");
}

// Create sample compliance tasks for demonstration
async function createSampleTasks() {
    try {
        console.log("Adding sample compliance tasks...");

        // Find the Tasks database
        const tasksDb = await findDatabaseByTitle("Tasks");

        if (!tasksDb) {
            throw new Error("Could not find the Tasks database.");
        }

        const sampleTasks = [
            {
                title: "Complete Monthly USP 797 Environmental Monitoring",
                description: "Perform air and surface sampling in cleanroom and buffer areas according to USP 797 requirements.",
                section: "USP 797 Compliance",
                priority: "High",
                status: "To Do",
                dueDate: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000), // 7 days from now
                pharmacy: "Central Pharmacy"
            },
            {
                title: "Annual Staff Competency Assessment",
                description: "Complete annual competency assessments for all staff members involved in sterile compounding.",
                section: "Staff Training",
                priority: "High",
                status: "To Do",
                dueDate: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000), // 30 days from now
                pharmacy: "Central Pharmacy"
            },
            {
                title: "Validate HEPA Filter Performance",
                description: "Schedule testing of HEPA filters in primary engineering controls to ensure proper function.",
                section: "Equipment Maintenance",
                priority: "Medium",
                status: "To Do",
                dueDate: new Date(Date.now() + 15 * 24 * 60 * 60 * 1000), // 15 days from now
                pharmacy: "Central Pharmacy"
            },
            {
                title: "Update USP 800 Hazardous Drug List",
                description: "Review and update the list of hazardous drugs handled by the pharmacy based on NIOSH guidelines.",
                section: "USP 800 Compliance",
                priority: "Medium",
                status: "To Do",
                dueDate: new Date(Date.now() + 10 * 24 * 60 * 60 * 1000), // 10 days from now
                pharmacy: "Central Pharmacy"
            },
            {
                title: "Document Refrigerator Temperature Logs",
                description: "Review and document daily temperature logs for medication refrigerators.",
                section: "Documentation",
                priority: "High",
                status: "In Progress",
                dueDate: new Date(Date.now() + 1 * 24 * 60 * 60 * 1000), // 1 day from now
                pharmacy: "Central Pharmacy"
            },
            {
                title: "Review Beyond-Use Dating Policies",
                description: "Ensure current beyond-use dating policies comply with USP 795 standards for non-sterile preparations.",
                section: "USP 795 Compliance",
                priority: "Medium",
                status: "To Do",
                dueDate: new Date(Date.now() + 14 * 24 * 60 * 60 * 1000), // 14 days from now
                pharmacy: "Central Pharmacy"
            },
        ];

        for (const task of sampleTasks) {
            await notion.pages.create({
                parent: {
                    database_id: tasksDb.id
                },
                properties: {
                    Title: {
                        title: [
                            {
                                text: {
                                    content: task.title
                                }
                            }
                        ]
                    },
                    Description: {
                        rich_text: [
                            {
                                text: {
                                    content: task.description
                                }
                            }
                        ]
                    },
                    Section: {
                        select: {
                            name: task.section
                        }
                    },
                    Completed: {
                        checkbox: false
                    },
                    Status: {
                        select: {
                            name: task.status
                        }
                    },
                    Priority: {
                        select: {
                            name: task.priority
                        }
                    },
                    DueDate: {
                        date: {
                            start: task.dueDate.toISOString().split('T')[0]
                        }
                    },
                    Pharmacy: {
                        rich_text: [
                            {
                                text: {
                                    content: task.pharmacy
                                }
                            }
                        ]
                    }
                }
            });
        }

        console.log(`Created ${sampleTasks.length} sample compliance tasks`);
    } catch (error) {
        console.error("Error creating sample tasks:", error);
    }
}

// Run the setup
async function main() {
    try {
        await setupTasksDatabase();
        await createSampleTasks();
        console.log("Notion Tasks setup complete!");
        process.exit(0);
    } catch (error) {
        console.error("Setup failed:", error);
        process.exit(1);
    }
}

main();