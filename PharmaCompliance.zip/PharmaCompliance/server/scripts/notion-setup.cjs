const { Client } = require("@notionhq/client");

// Environment variables validation
if (!process.env.NOTION_INTEGRATION_SECRET) {
    throw new Error("NOTION_INTEGRATION_SECRET is not defined. Please add it to your environment variables.");
}

if (!process.env.NOTION_PAGE_URL) {
    throw new Error("NOTION_PAGE_URL is not defined. Please add it to your environment variables.");
}

// Initialize Notion client
const notion = new Client({
    auth: process.env.NOTION_INTEGRATION_SECRET,
});

// Extract the page ID from the Notion page URL
function extractPageIdFromUrl(pageUrl) {
    const match = pageUrl.match(/([a-f0-9]{32})(?:[?#]|$)/i);
    if (match && match[1]) {
        return match[1];
    }

    throw Error("Failed to extract page ID");
}

const NOTION_PAGE_ID = extractPageIdFromUrl(process.env.NOTION_PAGE_URL);

async function getNotionDatabases() {
    // Array to store the child databases
    const childDatabases = [];

    try {
        // Query all child blocks in the specified page
        let hasMore = true;
        let startCursor = undefined;

        while (hasMore) {
            const response = await notion.blocks.children.list({
                block_id: NOTION_PAGE_ID,
                start_cursor: startCursor,
            });

            // Process the results
            for (const block of response.results) {
                // Check if the block is a child database
                if (block.type === "child_database") {
                    const databaseId = block.id;

                    // Retrieve the database title
                    try {
                        const databaseInfo = await notion.databases.retrieve({
                            database_id: databaseId,
                        });

                        // Add the database to our list
                        childDatabases.push(databaseInfo);
                    } catch (error) {
                        console.error(`Error retrieving database ${databaseId}:`, error);
                    }
                }
            }

            // Check if there are more results to fetch
            hasMore = response.has_more;
            startCursor = response.next_cursor || undefined;
        }

        return childDatabases;
    } catch (error) {
        console.error("Error listing child databases:", error);
        throw error;
    }
}

// Find a Notion database with the matching title
async function findDatabaseByTitle(title) {
    const databases = await getNotionDatabases();

    for (const db of databases) {
        if (db.title && Array.isArray(db.title)) {
            let dbTitle = "";
            // Extract the plain text from each title item
            for (const titleItem of db.title) {
                if (titleItem.type === "text" && titleItem.text && titleItem.text.content) {
                    dbTitle += titleItem.text.content;
                }
            }
            
            if (dbTitle.toLowerCase() === title.toLowerCase()) {
                return db;
            }
        }
    }

    return null;
}

// Create a new database if one with a matching title does not exist
async function createDatabaseIfNotExists(title, properties) {
    const existingDb = await findDatabaseByTitle(title);
    if (existingDb) {
        console.log(`Database "${title}" already exists with ID: ${existingDb.id}`);
        return existingDb;
    }
    
    console.log(`Creating new database "${title}"...`);
    return await notion.databases.create({
        parent: {
            type: "page_id",
            page_id: NOTION_PAGE_ID
        },
        title: [
            {
                type: "text",
                text: {
                    content: title
                }
            }
        ],
        properties: properties
    });
}

// Setup risk assessment database in Notion
async function setupNotionDatabases() {
    console.log(`Setting up Notion database in page ID: ${NOTION_PAGE_ID}`);

    const riskAssessmentsDb = await createDatabaseIfNotExists("Risk Assessments", {
        // Every database needs a Name/Title property
        Title: {
            title: {}
        },
        Description: {
            rich_text: {}
        },
        UspChapter: {
            select: {
                options: [
                    { name: "795", color: "blue" },
                    { name: "797", color: "green" },
                    { name: "800", color: "red" }
                ]
            }
        },
        Likelihood: {
            number: {}
        },
        Impact: {
            number: {}
        },
        DetectionDifficulty: {
            number: {}
        },
        RiskLevel: {
            number: {}
        },
        CurrentControls: {
            rich_text: {}
        },
        MitigationPlan: {
            rich_text: {}
        },
        Status: {
            select: {
                options: [
                    { name: "Not Started", color: "gray" },
                    { name: "In Progress", color: "blue" },
                    { name: "Implemented", color: "green" },
                    { name: "Verified", color: "purple" }
                ]
            }
        },
        Owner: {
            rich_text: {}
        },
        DueDate: {
            date: {}
        },
        Pharmacy: {
            rich_text: {}
        }
    });

    return riskAssessmentsDb;
}

// Create sample risk assessments in Notion
async function createSampleData(riskAssessmentsDb) {
    try {
        console.log("Adding sample risk assessment data...");

        if (!riskAssessmentsDb) {
            throw new Error("Could not find the Risk Assessments database.");
        }

        const sampleRisks = [
            {
                title: "Cross-contamination in non-sterile compounding",
                description: "Risk of cross-contamination between different compounds in non-sterile preparations",
                usp_chapter: "795",
                likelihood: 4,
                impact: 5,
                detection_difficulty: 3,
                risk_level: 20,
                current_controls: "Separate work areas for different compounds, cleaning between preparations",
                mitigation_plan: "Implement dedicated equipment for high-risk compounds, enhance cleaning protocols",
                mitigation_status: "In Progress",
                owner: "Dr. Maria Chen",
                due_date: new Date(2025, 5, 30).toISOString().split('T')[0],
                pharmacy: "Central Pharmacy"
            },
            {
                title: "Airflow disruption in sterile compounding area",
                description: "Risk of contamination due to inadequate airflow in sterile compounding areas",
                usp_chapter: "797",
                likelihood: 3,
                impact: 5,
                detection_difficulty: 4,
                risk_level: 15,
                current_controls: "Regular airflow testing, HEPA filters",
                mitigation_plan: "Install continuous airflow monitoring system with alerts",
                mitigation_status: "Not Started",
                owner: "Jennifer Wu",
                due_date: new Date(2025, 6, 15).toISOString().split('T')[0],
                pharmacy: "Central Pharmacy"
            },
            {
                title: "Hazardous drug exposure during preparation",
                description: "Staff exposure to hazardous drugs during preparation process",
                usp_chapter: "800",
                likelihood: 3,
                impact: 4,
                detection_difficulty: 3,
                risk_level: 12,
                current_controls: "PPE protocols, containment primary engineering controls",
                mitigation_plan: "Upgrade to closed-system transfer devices, enhanced staff training",
                mitigation_status: "Implemented",
                owner: "Robert Johnson",
                due_date: new Date(2025, 5, 20).toISOString().split('T')[0],
                pharmacy: "Central Pharmacy"
            },
            {
                title: "Temperature excursion in drug storage",
                description: "Risk of temperature excursions affecting drug stability and efficacy",
                usp_chapter: "797",
                likelihood: 2,
                impact: 4,
                detection_difficulty: 2,
                risk_level: 8,
                current_controls: "Manual temperature logs, refrigerator alarms",
                mitigation_plan: "Implement automated temperature monitoring system with remote alerts",
                mitigation_status: "In Progress",
                owner: "Dr. Maria Chen",
                due_date: new Date(2025, 5, 25).toISOString().split('T')[0],
                pharmacy: "Central Pharmacy"
            },
            {
                title: "Incorrect beyond-use date assignment",
                description: "Risk of assigning incorrect beyond-use dates to compounded preparations",
                usp_chapter: "795",
                likelihood: 3,
                impact: 4,
                detection_difficulty: 4,
                risk_level: 12,
                current_controls: "Staff training, BUD calculation worksheets",
                mitigation_plan: "Develop computerized BUD calculator integrated with lab results",
                mitigation_status: "Not Started",
                owner: "Jennifer Wu",
                due_date: new Date(2025, 6, 30).toISOString().split('T')[0],
                pharmacy: "Central Pharmacy"
            }
        ];

        for (const risk of sampleRisks) {
            console.log(`Creating risk assessment: ${risk.title}`);
            await notion.pages.create({
                parent: {
                    database_id: riskAssessmentsDb.id
                },
                properties: {
                    Title: {
                        title: [
                            {
                                text: {
                                    content: risk.title
                                }
                            }
                        ]
                    },
                    Description: {
                        rich_text: [
                            {
                                text: {
                                    content: risk.description
                                }
                            }
                        ]
                    },
                    UspChapter: {
                        select: {
                            name: risk.usp_chapter
                        }
                    },
                    Likelihood: {
                        number: risk.likelihood
                    },
                    Impact: {
                        number: risk.impact
                    },
                    DetectionDifficulty: {
                        number: risk.detection_difficulty
                    },
                    RiskLevel: {
                        number: risk.risk_level
                    },
                    CurrentControls: {
                        rich_text: [
                            {
                                text: {
                                    content: risk.current_controls
                                }
                            }
                        ]
                    },
                    MitigationPlan: {
                        rich_text: [
                            {
                                text: {
                                    content: risk.mitigation_plan
                                }
                            }
                        ]
                    },
                    Status: {
                        select: {
                            name: risk.mitigation_status
                        }
                    },
                    Owner: {
                        rich_text: [
                            {
                                text: {
                                    content: risk.owner
                                }
                            }
                        ]
                    },
                    DueDate: {
                        date: {
                            start: risk.due_date
                        }
                    },
                    Pharmacy: {
                        rich_text: [
                            {
                                text: {
                                    content: risk.pharmacy
                                }
                            }
                        ]
                    }
                }
            });
        }

        console.log("Sample data creation complete!");
    } catch (error) {
        console.error("Error creating sample data:", error);
        throw error;
    }
}

// Run the setup
async function main() {
    try {
        console.log("Starting Notion setup...");
        const riskAssessmentsDb = await setupNotionDatabases();
        await createSampleData(riskAssessmentsDb);
        console.log("Notion setup complete!");
    } catch (error) {
        console.error("Notion setup failed:", error);
        process.exit(1);
    }
}

main();