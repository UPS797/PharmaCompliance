import { Client } from "@notionhq/client";
import { notion, findDatabaseByTitle } from "../notion";

// Environment variables validation
if (!process.env.NOTION_INTEGRATION_SECRET) {
    throw new Error("NOTION_INTEGRATION_SECRET is not defined. Please add it to your environment variables.");
}

if (!process.env.NOTION_PAGE_URL) {
    throw new Error("NOTION_PAGE_URL is not defined. Please add it to your environment variables.");
}

/**
 * This script directly uses the database provided in NOTION_PAGE_URL without trying to create a new one
 */
async function setupTasksInExistingDatabase() {
    // Extract the database ID directly from the URL
    const urlParts = process.env.NOTION_PAGE_URL!.split('?v=');
    if (urlParts.length < 2) {
        throw new Error("The provided Notion URL doesn't appear to be a database URL");
    }

    const databaseId = urlParts[1];
    console.log(`Using existing database ID: ${databaseId}`);

    return databaseId;
}

async function createSampleTasks(databaseId: string) {
    try {
        console.log("Adding sample pharmacy compliance tasks...");

        // First, let's check the properties of the database to see what we're working with
        const databaseInfo = await notion.databases.retrieve({
            database_id: databaseId
        });

        console.log("Database properties:", JSON.stringify(databaseInfo.properties, null, 2));

        // Sample tasks for USP compliance
        const tasks = [
            {
                title: "Monthly hood certification - USP 800",
                description: "Perform monthly certification of containment primary engineering control (C-PEC) hoods for handling hazardous drugs",
                section: "USP 800",
                priority: "High"
            },
            {
                title: "Daily pressure differential check - USP 797",
                description: "Monitor and document pressure differential between clean room and ante-room",
                section: "USP 797",
                priority: "High"
            },
            {
                title: "Temperature monitoring - USP 795",
                description: "Record temperature readings for non-sterile compounding areas",
                section: "USP 795",
                priority: "Medium"
            },
            {
                title: "Quarterly staff competency assessment - USP 797",
                description: "Evaluate staff competencies for aseptic technique and cleaning procedures",
                section: "USP 797",
                priority: "Medium"
            },
            {
                title: "Annual training review - USP 800",
                description: "Conduct annual review of hazardous drug handling training for all pharmacy personnel",
                section: "USP 800",
                priority: "Medium"
            },
            {
                title: "Surface sampling for radiopharmaceuticals - USP 825",
                description: "Perform monthly surface sampling for radiopharmaceutical preparation areas",
                section: "USP 825",
                priority: "High"
            }
        ];

        // Create a version of createPage that adapts to the existing database structure
        for (let task of tasks) {
            try {
                // We'll need to adapt our properties based on what exists in the database
                const properties: any = {};
                
                // Most Notion databases have a "Name" or "Title" property
                // Find the title property
                const titleProperty = Object.entries(databaseInfo.properties).find(([_, prop]) => 
                    prop.type === 'title'
                );
                
                if (titleProperty) {
                    properties[titleProperty[0]] = {
                        title: [
                            {
                                text: {
                                    content: task.title
                                }
                            }
                        ]
                    };
                }
                
                // Try to add other properties if they exist
                // Description/Notes (rich_text)
                const descProperty = Object.entries(databaseInfo.properties).find(([key, prop]) => 
                    prop.type === 'rich_text' && 
                    (key.toLowerCase().includes('desc') || key.toLowerCase().includes('note'))
                );
                
                if (descProperty) {
                    properties[descProperty[0]] = {
                        rich_text: [
                            {
                                text: {
                                    content: task.description
                                }
                            }
                        ]
                    };
                }
                
                // Section/Category (select)
                const sectionProperty = Object.entries(databaseInfo.properties).find(([key, prop]) => 
                    prop.type === 'select' && 
                    (key.toLowerCase().includes('section') || key.toLowerCase().includes('category'))
                );
                
                if (sectionProperty) {
                    properties[sectionProperty[0]] = {
                        select: {
                            name: task.section
                        }
                    };
                }
                
                // Priority (select)
                const priorityProperty = Object.entries(databaseInfo.properties).find(([key, prop]) => 
                    prop.type === 'select' && key.toLowerCase().includes('priority')
                );
                
                if (priorityProperty) {
                    properties[priorityProperty[0]] = {
                        select: {
                            name: task.priority
                        }
                    };
                }
                
                // Status (select/status)
                const statusProperty = Object.entries(databaseInfo.properties).find(([key, prop]) => 
                    (prop.type === 'select' || prop.type === 'status') && 
                    key.toLowerCase().includes('status')
                );
                
                if (statusProperty) {
                    if (statusProperty[1].type === 'select') {
                        properties[statusProperty[0]] = {
                            select: {
                                name: "To Do"
                            }
                        };
                    } else if (statusProperty[1].type === 'status') {
                        properties[statusProperty[0]] = {
                            status: {
                                name: "Not started"
                            }
                        };
                    }
                }
                
                console.log(`Creating task: ${task.title}`);
                console.log(`Properties: ${JSON.stringify(properties, null, 2)}`);
                
                await notion.pages.create({
                    parent: {
                        database_id: databaseId
                    },
                    properties
                });
                
                console.log(`Created task: ${task.title}`);
            } catch (error) {
                console.error(`Error creating task ${task.title}:`, error);
            }
        }

        console.log("Sample pharmacy compliance tasks created successfully.");
    } catch (error) {
        console.error("Error creating sample data:", error);
        throw error;
    }
}

async function main() {
    try {
        console.log("Starting direct Notion database setup...");
        
        // Use the existing database from the URL
        const databaseId = await setupTasksInExistingDatabase();
        
        // Create sample tasks in the existing database
        await createSampleTasks(databaseId);
        
        console.log("Notion integration setup complete!");
        process.exit(0);
    } catch (error) {
        console.error("Setup failed:", error);
        process.exit(1);
    }
}

// Run the setup
main();