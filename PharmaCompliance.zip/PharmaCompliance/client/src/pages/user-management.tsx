import UserManagement from "@/components/admin/user-management";

export default function UserManagementPage() {
  return (
    <div className="container mx-auto p-6">
      <UserManagement />
    </div>
  );
}